package com.example.helloworldapi;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloworldapiApplicationTests {

	@Test
	void contextLoads() {
	}

}
